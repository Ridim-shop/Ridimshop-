// ============================================
// ZIP. — interactions
// ============================================

document.addEventListener('DOMContentLoaded', () => {
  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  runCompressionMeter(prefersReducedMotion);
  runCountUps(prefersReducedMotion);
  markCardsAndStepsForReveal();
  runScrollReveal(prefersReducedMotion);
});

/**
 * Hero signature element: animates a fake file shrinking from
 * 128.4 MB down to 4.9 MB, with the bar and label updating together.
 */
function runCompressionMeter(reduced){
  const fill = document.getElementById('meterFill');
  const after = document.getElementById('sizeAfter');
  const percent = document.getElementById('meterPercent');
  const status = document.getElementById('meterStatus');
  if (!fill || !after || !percent || !status) return;

  const startMB = 128.4;
  const endMB = 4.9;
  const reduction = Math.round((1 - endMB / startMB) * 100);

  if (reduced){
    fill.style.width = `${reduction}%`;
    after.textContent = `${endMB} MB`;
    percent.textContent = `${reduction}% smaller`;
    status.textContent = 'compressed';
    return;
  }

  // small delay so the page settles before the animation draws attention
  setTimeout(() => {
    fill.style.width = `${reduction}%`;
    status.textContent = 'compressing…';

    const duration = 1600;
    const start = performance.now();

    function step(now){
      const t = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - t, 3); // ease-out cubic
      const currentMB = startMB - (startMB - endMB) * eased;
      const currentPercent = Math.round((1 - currentMB / startMB) * 100);

      after.textContent = `${currentMB.toFixed(1)} MB`;
      percent.textContent = `${currentPercent}% smaller`;

      if (t < 1){
        requestAnimationFrame(step);
      } else {
        after.textContent = `${endMB} MB`;
        percent.textContent = `${reduction}% smaller`;
        status.textContent = 'compressed';
      }
    }
    requestAnimationFrame(step);
  }, 500);
}

/**
 * Animates the stat numbers counting up when they scroll into view.
 */
function runCountUps(reduced){
  const stats = document.querySelectorAll('.stat__num');
  if (!stats.length) return;

  const animate = (el) => {
    const staticText = el.dataset.static;
    if (staticText){
      el.textContent = staticText;
      return;
    }

    const target = parseFloat(el.dataset.target);
    const suffix = el.dataset.suffix || '';
    const decimals = parseInt(el.dataset.decimal || '0', 10);

    if (reduced){
      el.textContent = `${target.toFixed(decimals)}${suffix}`;
      return;
    }

    const duration = 1400;
    const start = performance.now();

    function step(now){
      const t = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - t, 3);
      const current = target * eased;
      el.textContent = `${current.toFixed(decimals)}${suffix}`;
      if (t < 1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  };

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting){
        animate(entry.target);
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.5 });

  stats.forEach(el => observer.observe(el));
}

/**
 * Tags feature cards and steps with the .reveal class so they
 * fade/slide in on scroll rather than all appearing at once.
 */
function markCardsAndStepsForReveal(){
  document.querySelectorAll('.card, .step').forEach(el => {
    el.classList.add('reveal');
  });
}

function runScrollReveal(reduced){
  const items = document.querySelectorAll('.reveal');
  if (!items.length) return;

  if (reduced){
    items.forEach(el => el.classList.add('is-visible'));
    return;
  }

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting){
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15 });

  items.forEach(el => observer.observe(el));
}
